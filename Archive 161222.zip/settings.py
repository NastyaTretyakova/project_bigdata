DSL = {
    'dbname': 'test',
    'user': 'test',
    'password': 'test',
    'host': 'localhost',
    'port': '5432',
}